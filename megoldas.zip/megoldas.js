/*1.,*/
document.write("Szekeres László<br>");
document.write("#Team13<br>");
document.write("HTML:95<br>");
document.write("CSS:80<br>");
document.write("JavaScript:60");


/*2.,*/
let szam=Number(prompt("Adjon meg egy számot"));
let hatvany=Number(prompt("Adja meg a hatványt"));
let osszeg=szam**hatvany
document.write(`A ${szam}<sup>${hatvany}</sup>=${osszeg}`);


/*3.,*/
let also=Number(prompt("Adja meg az alsó határt"));
let felso=Number(prompt("Adja meg a felső határt"));
let generaltSzam=Math.round(Math.random()*(felso-also))+also;
if(generaltSzam%2==0){
	document.write(`${generaltSzam} szám páros.`);
}
else if(generaltSzam!=felso){
	document.write(`${generaltSzam+1} szám páros`)
}

else{
	document.write(`${generaltSzam-1} szám páros`)
}


/*4.,*/
let kor=Number(prompt("Adja meg az életkorát!"))
if(kor>=0 && kor<6){
	document.write("Kisgyermekkor")
}

else if(kor>=6 && kor<12){
	document.write("Gyermekkor")
}

else if(kor>=12 && kor<16){
	document.write("Serdülőkor")
}

else if(kor>=16 && kor<20){
	document.write("Ifjúkor")
}

else if(kor>=20 && kor<30){
	document.write("Fiatal felnőtt kor")
}

else if(kor>=30 && kor<60){
	document.write("Felnőtt kor")
}

else if(kor>=60 && kor<=120){
	document.write("Aggkor");
}

else if(kor>120){
	document.write("Hát hogy élné má eddig?")
}

else{
	document.write("Érdekes életkor..")
}


/*5.,*/
let szam=Number(prompt("Adjon meg egy számot"));
let oszto=Number(prompt("Adja meg az osztót"));
if(szam%oszto==0){
	document.write(`A ${szam} osztható a(z) ${oszto} számmal`);
}

else{
	document.write(`A ${szam} NEM osztható a(z) ${oszto} számmal`)
}


/*6.,*/
for(let i=1;i<=10;i++){
	document.write(i*i+",");
}